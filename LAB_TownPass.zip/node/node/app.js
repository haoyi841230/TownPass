const express = require('express');
const mysql = require('mysql2');
const axios = require('axios');
const bodyParser = require('body-parser');
const cors = require('cors');
const https = require('https');
const fs = require('fs');
const path = require('path'); // 导入 path 模块
require('dotenv').config(); // 载入环境变量

// 初始化 Express 应用程序
const app = express();

// 设置 MySQL 连接池，从 .env 文件中读取配置
const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: process.env.DB_CONNECTION_LIMIT,
    queueLimit: 0
});

// 使用 bodyParser 解析请求的 JSON
app.use(bodyParser.json());
app.use(cors()); // 启用 CORS

// 从台北市政府开放数据平台获取数据并存入 MySQL 数据库
app.get('/fetch-and-store', async (req, res) => {
    try {
        const response = await axios.get('https://data.taipei/api/v1/dataset/2749b84d-a09c-4c03-a7ff-710e7ebf209c?scope=resourceAquire');
        
        if (response.data && response.data.result && response.data.result.results) {
            const activities = response.data.result.results;

            // 将数据插入到数据库中
            activities.forEach((activity) => {
                const { 檔案名稱, 介接網址, 主要欄位說明, 更新頻率, 檔案格式, 說明文件 } = activity;
                pool.query(
                    'INSERT INTO cultural_activities (act_name, location, start_date, end_date, description, org_name, source_web) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [檔案名稱, 介接網址, null, null, 主要欄位說明, 更新頻率, 說明文件],
                    (err) => {
                        if (err) console.error('Error inserting data: ', err);
                    }
                );
            });

            res.send('Data fetched and stored successfully!');
        } else {
            throw new Error('Invalid API response structure');
        }
    } catch (error) {
        console.error('Error fetching data: ', error.message);
        res.status(500).send('Error fetching data');
    }
});

app.get('/account', async (req, res) => {
    try {
        // Define the path to the JSON file
        const filePath = path.join(process.cwd(), '..', '..',  'assets', 'mock_data', 'account.json');

        // Use the already declared fs module to read the file
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                console.error('Error reading JSON file: ', err);
                res.status(500).send('Error reading data');
                return;
            }

            // Parse the JSON data
            const activities = JSON.parse(data);

            res.json(activities);  // Send the parsed data back as a response
        });
    } catch (error) {
        console.error('Error processing request: ', error.message);
        res.status(500).send('Error processing request');
    }
});


app.post('/query-courses', (req, res) => {
    const { main_category, sub_category, course_name } = req.body;

    let query = 'SELECT * FROM Taipei_eUniversity_Course_List WHERE 1=1';
    let queryParams = [];

    // 根據請求體中的條件進行查詢過濾
    if (main_category) {
        query += ' AND main_category = ?';
        queryParams.push(main_category);
    }
    if (sub_category) {
        query += ' AND sub_category = ?';
        queryParams.push(sub_category);
    }
    if (course_name) {
        query += ' AND course_name LIKE ?';
        queryParams.push(`%${course_name}%`);
    }

    // 執行 SQL 查詢
    pool.query(query, queryParams, (err, results) => {
        if (err) {
            console.error('Error querying data: ', err);
            res.status(500).send('Error querying data');
            return;
        }
        res.json(results); // 返回查詢結果
    });
});
app.post('/query-bus', (req, res) => {
    //const { main_category, sub_category, course_name } = req.body;

    let query = 'SELECT * FROM bus_stops WHERE 1=1';
    // 執行 SQL 查詢
    //pool.query(query, queryParams, (err, results) => {
    pool.query(query, (err, results) => {
        if (err) {
            console.error('Error querying data: ', err);
            res.status(500).send('Error querying data');
            return;
        }
        res.json(results); // 返回查詢結果
    });
});

app.post('/query-metro', (req, res) => {
    //const { main_category, sub_category, course_name } = req.body;

    let query = 'SELECT * FROM metro_stations WHERE 1=1';
    // 執行 SQL 查詢
    //pool.query(query, queryParams, (err, results) => {
    pool.query(query, (err, results) => {
        if (err) {
            console.error('Error querying data: ', err);
            res.status(500).send('Error querying data');
            return;
        }
        res.json(results); // 返回查詢結果
    });
});
// POST 查詢 API
app.post('/search-courses', (req, res) => {
    const { course_name, enrollment, class_start_date, class_end_date } = req.body;

    let query = 'SELECT * FROM Taipei_City_Vocational_Training_Class WHERE 1=1';
    let queryParams = [];

    // 根據請求體中的條件動態組建 SQL 查詢
    if (course_name) {
        query += ' AND course_name LIKE ?';
        queryParams.push(`%${course_name}%`);
    }
    if (enrollment) {
        query += ' AND enrollment = ?';
        queryParams.push(enrollment);
    }
    if (class_start_date) {
        query += ' AND class_start_date >= ?';
        queryParams.push(class_start_date);
    }
    if (class_end_date) {
        query += ' AND class_end_date <= ?';
        queryParams.push(class_end_date);
    }

    // 執行查詢
    pool.query(query, queryParams, (err, results) => {
        if (err) {
            console.error('Error querying data: ', err);
            res.status(500).send('Error querying data');
            return;
        }
        res.json(results); // 返回查詢結果
    });
});
app.post('/increment-click', (req, res) => {
    const { 資料表來源, 序號 } = req.body;

    // Validate the request input
    if (!資料表來源 || !序號) {
        return res.status(400).send('資料表來源 and 序號 are required');
    }

    // Validate that the source table is a valid table name
    const validTables = ['FreeDigitalCourses_TaipeiCitizens', 'Taipei_eUniversity_Course_List','courses']; // Add any other valid table names here
    if (!validTables.includes(資料表來源)) {
        return res.status(400).send('Invalid 資料表來源');
    }

    // Step 1: Query the current 點擊次數 from the specified table
    pool.query(`SELECT 點擊次數 FROM ?? WHERE id = ?`, [資料表來源, 序號], (err, results) => {
        if (err) {
            return res.status(500).send('Error fetching data');
        }

        if (results.length === 0) {
            return res.status(404).send('Record not found');
        }

        const currentClickCount = results[0].點擊次數;

        // Step 2: Increment 點擊次數 by 1
        const updatedClickCount = currentClickCount + 1;

        // Step 3: Update the 點擊次數 in the specified table
        pool.query(
            `UPDATE ?? SET 點擊次數 = ? WHERE id = ?`,
            [資料表來源, updatedClickCount, 序號],
            (updateErr, updateResults) => {
                if (updateErr) {
                    return res.status(500).send('Error updating click count');
                }

                res.status(200).send(`點擊次數 updated successfully to ${updatedClickCount}`);
            }
        );
    });
});
// 查询数据并返回给前端
app.post('/query', (req, res) => {
    const { 年度, 序號, 行政區, 上課地點, 課程名稱, 上課日期, 上課日期_迄, 上課時間_起, 上課時間_迄 } = req.body;
    console.log(req.body);
    let query = 'SELECT * FROM FreeDigitalCourses_TaipeiCitizens WHERE 1=1';
    let queryParams = [];
    
    if (年度) {
        query += ' AND 年度 = ?';
        queryParams.push(年度);
    }
    if (序號) {
        query += ' AND 序號 = ?';
        queryParams.push(序號);
    }
    if (行政區) {
        query += ' AND 行政區 = ?';
        queryParams.push(行政區);
    }
    if (上課地點) {
        query += ' AND 上課地點 = ?';
        queryParams.push(上課地點);
    }
    if (課程名稱) {
        query += ' AND 課程名稱 LIKE ?';
        queryParams.push(`%${課程名稱}%`);
    }
    if (上課日期) {
        query += ' AND 上課日期 >= ?';
        queryParams.push(上課日期);
    }
    if (上課日期_迄) {
        query += ' AND 上課日期 <= ?';
        queryParams.push(上課日期_迄);
    }
    if (上課時間_起) {
        query += ' AND `上課時間_起` >= ?';
        queryParams.push(上課時間_起);
    }
    if (上課時間_迄) {
        query += ' AND `上課時間_迄` <= ?';
        queryParams.push(上課時間_迄);
    }

    pool.query(query, queryParams, (err, results) => {
        if (err) {
            console.error('Error querying data: ', err);
            res.status(500).send('Error querying data');
            return;
        }
        res.json(results);
    });
});
// 查詢職訓局課程
app.post('/courses_online', (req, res) => {
    const { course_name, start_date, end_date } = req.body;
    console.log(req.body);
    
    let sqlQuery = 'SELECT * FROM courses_online WHERE 1=1';
    const queryParams = [];
  
    if (course_name) {
      sqlQuery += ' AND course_name LIKE ?';
      queryParams.push(`%${course_name}%`);
    }
  
    if (start_date) {
      sqlQuery += ' AND class_start_date >= STR_TO_DATE(?, "%Y-%m-%d")';
      queryParams.push(start_date);
    }
  
    if (end_date) {
      sqlQuery += ' AND class_end_date <= STR_TO_DATE(?, "%Y-%m-%d")';
      queryParams.push(end_date);
    }
  
    // Execute the query
    pool.query(sqlQuery, queryParams, (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ courses: results });
    });
  });
  app.post('/courses_query', (req, res) => {
    const {
      id,
      category,
      course_name,
      enrollment,
      start_date,
      end_date,
      class_hours,
      course_start,
      course_end,
      description,
      contact
    } = req.body;
  
    // Build the SQL query with optional filtering
    let sqlQuery = 'SELECT * FROM courses WHERE 1=1';
    const queryParams = [];
  
    if (id) {
      sqlQuery += ' AND id = ?';
      queryParams.push(id);
    }
  
    if (category) {
      sqlQuery += ' AND category LIKE ?';
      queryParams.push(`%${category}%`);
    }
  
    if (course_name) {
      sqlQuery += ' AND course_name LIKE ?';
      queryParams.push(`%${course_name}%`);
    }
  
    if (enrollment) {
      sqlQuery += ' AND enrollment = ?';
      queryParams.push(enrollment);
    }
  
    if (start_date) {
      sqlQuery += ' AND start_date = ?';
      queryParams.push(start_date);
    }
  
    if (end_date) {
      sqlQuery += ' AND end_date = ?';
      queryParams.push(end_date);
    }
  
    if (class_hours) {
      sqlQuery += ' AND class_hours = ?';
      queryParams.push(class_hours);
    }
  
    if (course_start) {
      sqlQuery += ' AND course_start = ?';
      queryParams.push(course_start);
    }
  
    if (course_end) {
      sqlQuery += ' AND course_end = ?';
      queryParams.push(course_end);
    }
  
    if (description) {
      sqlQuery += ' AND description LIKE ?';
      queryParams.push(`%${description}%`);
    }
  
    if (contact) {
      sqlQuery += ' AND contact LIKE ?';
      queryParams.push(`%${contact}%`);
    }
  
    // Execute the query
    pool.query(sqlQuery, queryParams, (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ courses: results });
    });
  });
app.post('/Ecourses_query', (req, res) => {
    const {
      id, 
      main_category, 
      sub_category, 
      sub_sub_category, 
      course_name, 
      course_link, 
      enrollment, 
      certification_hours
    } = req.body;
  
    // Build the SQL query with optional filtering
    let sqlQuery = 'SELECT * FROM Taipei_eUniversity_Course_List WHERE 1=1';
    const queryParams = [];
  
    if (id) {
      sqlQuery += ' AND id = ?';
      queryParams.push(id);
    }
  
    if (main_category) {
      sqlQuery += ' AND main_category LIKE ?';
      queryParams.push(`%${main_category}%`);
    }
  
    if (sub_category) {
      sqlQuery += ' AND sub_category LIKE ?';
      queryParams.push(`%${sub_category}%`);
    }
  
    if (sub_sub_category) {
      sqlQuery += ' AND sub_sub_category LIKE ?';
      queryParams.push(`%${sub_sub_category}%`);
    }
  
    if (course_name) {
      sqlQuery += ' AND course_name LIKE ?';
      queryParams.push(`%${course_name}%`);
    }
  
    if (course_link) {
      sqlQuery += ' AND course_link LIKE ?';
      queryParams.push(`%${course_link}%`);
    }
  
    if (enrollment) {
      sqlQuery += ' AND enrollment = ?';
      queryParams.push(enrollment);
    }
  
    if (certification_hours) {
      sqlQuery += ' AND certification_hours = ?';
      queryParams.push(certification_hours);
    }
  
    // Execute the query
    pool.query(sqlQuery, queryParams, (err, results) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ courses: results });
    });
  });


// HTTPS 服务器设置
const httpsOptions = {
    key: fs.readFileSync(path.resolve(__dirname, 'CA/RSA-privkey.pem')),
    cert: fs.readFileSync(path.resolve(__dirname, 'CA/RSA-cert.pem')),
    ca: fs.readFileSync(path.resolve(__dirname, 'CA/RSA-chain.pem'))  // 证书链
};

// 启动 HTTPS 服务器
const PORT = process.env.PORT || 3000;
https.createServer(httpsOptions, app).listen(PORT, () => {
    console.log(`HTTPS Server is running on port ${PORT}`);
});
