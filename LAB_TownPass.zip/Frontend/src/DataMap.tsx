import { Box } from '@mui/material';
import { MutableRefObject, useEffect, useRef } from 'react';
import { getLatitudeAndLongitude } from './api';
import { useQuery } from '@tanstack/react-query';
import { Response } from './api/model';
import mapboxgl, { LngLatLike } from 'mapbox-gl';

mapboxgl.accessToken = import.meta.env.VITE_MAPBOXTOKEN;

export const DataMap = ({
  bottomRef,
  selectedClass,
}: {
  bottomRef: MutableRefObject<HTMLElement | null>;
  selectedClass: Response | null;
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const map = useRef<mapboxgl.Map | null>(null);

  const { data, isSuccess } = useQuery({
    queryKey: ['coordinate', selectedClass],
    queryFn: () =>
      getLatitudeAndLongitude({
        address: selectedClass?.上課地點.substring(0, 20)!,
        accessToken: import.meta.env.VITE_MAPBOXTOKEN,
      }),
    enabled: !!selectedClass,
  });

  //Init Map
  useEffect(() => {
    if (mapContainerRef.current) {
      map.current = new mapboxgl.Map({
        container: mapContainerRef.current,
        style: 'mapbox://styles/mapbox/streets-v12',
        center: [121.565, 25.033],
        zoom: 15,
      });
    }

    map.current?.addControl(new mapboxgl.NavigationControl(), 'top-right');
    map.current?.addControl(new mapboxgl.FullscreenControl());

    map.current?.addControl(
      new mapboxgl.GeolocateControl({
        positionOptions: {
          enableHighAccuracy: true,
        },
        trackUserLocation: true,
        showUserHeading: true,
      }),
    );

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userLocation: LngLatLike = [position.coords.longitude, position.coords.latitude];

          map.current?.setCenter(userLocation);
          new mapboxgl.Marker().setLngLat(userLocation).addTo(map.current!);
        },
        () => console.log('無法獲取用戶位置。'),
      );
    } else {
      console.log('瀏覽器不支持地理定位。');
    }

    map.current?.on('load', () => {
      map.current?.resize();
    });

    return () => map.current?.remove();
  }, []);

  useEffect(() => {
    if (data) {
      const { latitude, longitude } = data;

      new mapboxgl.Marker({
        scale: 0.7,
        color: 'red',
      })
        .setLngLat([longitude, latitude])
        .setPopup(
          new mapboxgl.Popup({
            closeButton: true,
          })
            .setLngLat([longitude, latitude])
            .setHTML(
              `<div>
                <h1>${selectedClass?.['課程名稱']}</h1>
                <h3>${selectedClass?.['上課地點']}</h3>
                </div>`,
            )
            .addTo(map.current!),
        )
        .addTo(map.current!);

      map.current?.setCenter([longitude, latitude]);
    }
  }, [isSuccess, data]);

  return (
    <Box className="map-container" ref={mapContainerRef} height="300px" width="100%">
      <Box ref={bottomRef} />
    </Box>
  );
};
