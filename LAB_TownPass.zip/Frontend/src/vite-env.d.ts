/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_MAPBOXTOKEN: string;
  readonly VITE_MAPBOXTILE: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
