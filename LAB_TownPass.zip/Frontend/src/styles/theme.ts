import { boxShadow } from './customStyleVariables';

import { brand, common, customGrey, customSecondaryColor } from './customColorsVariables';

export const defaultTheme = {
  palette: {
    primary: {
      main: brand[500],
      dark: brand[800],
      light: brand[400],
      contrastText: common.white,
    },
    secondary: {
      main: customSecondaryColor[500],
      dark: customSecondaryColor[800],
      light: customSecondaryColor[400],
      contrastText: common.white,
    },
    error: {
      main: '#D45251',
      light: '#E29494',
    },
    success: {
      main: '#76A732',
    },
    text: {
      primary: customGrey[800],
      secondary: customGrey[700],
      disabled: customGrey[400],
    },
    action: {
      disabledBackground: customGrey[200],
      disabled: customGrey[600],
    },
    common: {
      black: common.black,
      white: common.white,
    },
    background: {
      paper: common.white,
      default: customGrey[100],
    },
    grey: {
      50: customGrey[50],
      100: customGrey[100],
      200: customGrey[200],
      300: customGrey[300],
      400: customGrey[400],
      500: customGrey[500],
      600: customGrey[600],
      700: customGrey[700],
      800: customGrey[800],
      900: customGrey[900],
    },
    brand,
    customGrey,
    boxShadow,
  },
  typography: {
    fontFamily: "'PingFang 蘋方','Roboto', 'sans-serif'",
    h1: {
      fontSize: '36px',
    },
    h2: {
      fontSize: '24px',
    },
    h3: {
      fontSize: '16px',
    },
    body1: {
      fontSize: '14px',
    },
    caption: {
      fontSize: '12px',
    },
  },
};
