import { boxShadowsColor } from './customColorsVariables';

export const boxShadow = {
  xs: `0px 1px 2px 0px ${boxShadowsColor['xs']}`,
  'sm-01': `0px 1px 2px 0px ${boxShadowsColor['sm-01']}`,
  'sm-02': `0px 1px 3px 0px ${boxShadowsColor['sm-02']}`,
  'md-01': `0px 2px 4px -2px ${boxShadowsColor['md-01']}`,
  'md-02': `0px 4px 8px - 2px ${boxShadowsColor['md-02']}`,
  'lg-01': `0px 4px 6px -2px ${boxShadowsColor['lg-01']}`,
  'lg-02': `0px 12px 16px -4px ${boxShadowsColor['lg-02']}`,
  'xl-01': `0px 8px 8px -4px ${boxShadowsColor['xl-01']}`,
  'xl-02': `0px 20px 24px -4px ${boxShadowsColor['xl-02']}`,
  '2xl': `0px 24px 48px -12px ${boxShadowsColor['2xl']}`,
  '3xl': `0px 32px 64px -12px ${boxShadowsColor['3xl']}`,
};
