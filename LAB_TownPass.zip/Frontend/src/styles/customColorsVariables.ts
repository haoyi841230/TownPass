import { alpha } from '@mui/material';
import './themeDefinition.ts';

export const common = {
  black: '#000000',
  white: '#FFFFFF',
};

export const customGrey = {
  50: '#EDF8FA',
  100: '#E3E7E9',
  200: '#CAD1D5',
  300: '#ADB8BE',
  400: '#91A0A8',
  500: '#738995',
  600: '#5E6D76',
  700: '#475259',
  800: '#30383D',
  900: '#171B1D',
  950: '#2C2F32',
};

export const brand = {
  50: '#EDF8FA',
  100: '#DBF1F5',
  200: '#B4E2EA',
  300: '#93D4DF',
  400: '#71C5D5',
  500: '#5AB4C5',
  600: '#468D9B',
  700: '#356C77',
  800: '#22474E',
  900: '#112629',
  950: '#081315',
};

export const customSecondaryColor = {
  50: '#FDF8ED',
  100: '#FCF2DF',
  200: '#F8E3BC',
  300: '#F4D69E',
  400: '#F0C87C',
  500: '#F5BA4B',
  600: '#E7A43C',
  700: '#AD7B2B',
  800: '#74521B',
  900: '#3C2B0B',
  950: '#1C1304',
};

export const boxShadowsColor = {
  '2xl': alpha('#101828', 0.18),
  '3xl': alpha('#101828', 0.14),
  'lg-01': alpha('#101828', 0.08),
  'lg-02': alpha('#101828', 0.03),
  'md-01': alpha('#101828', 0.1),
  'md-02': alpha('#101828', 0.06),
  'sm-01': alpha('#101828', 0.1),
  'sm-02': alpha('#101828', 0.06),
  'xl-01': alpha('#101828', 0.08),
  'xl-02': alpha('#101828', 0.03),
  xs: alpha('#101828', 0.05),
};
