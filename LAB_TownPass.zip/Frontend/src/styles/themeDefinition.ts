import { Theme, createTheme } from '@mui/material';
import { defaultTheme } from './theme';
import { brand, customGrey, customSecondaryColor } from './customColorsVariables';
import { boxShadow } from './customStyleVariables';

export const DEFAULT_THEME: Theme = createTheme(defaultTheme);

declare module '@mui/material/styles' {
  interface Palette {
    brand: typeof brand;
    customGrey: typeof customGrey;
    boxShadow: typeof boxShadow;
    customSecondaryColor: typeof customSecondaryColor;
  }
}
