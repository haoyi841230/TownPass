import { CssBaseline, Stack } from '@mui/material';
import { Outlet } from 'react-router-dom';

export const NAV_BAR_HEIGHT = 12;
export const SIDEBAR_WIDTH = 32;
export const FOOTER_HEIGHT = 12;

export const DashboardLayout = () => {
  return (
    <Stack direction="column" width="100%" minHeight="100vh">
      <CssBaseline />
      <Stack px="24px" py="36px" height="100%">
        <Outlet />
      </Stack>
    </Stack>
  );
};
