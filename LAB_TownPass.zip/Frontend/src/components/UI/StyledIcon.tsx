import { Icon, styled } from '@mui/material';

export const StyledIcon = styled(Icon)(() => ({
  color: 'text.primary',
  overflow: 'visible',
}));
