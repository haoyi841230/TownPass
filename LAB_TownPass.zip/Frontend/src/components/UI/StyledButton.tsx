import { Button, styled } from '@mui/material';

export const StyledButton = styled(Button)(() => {
  return {
    borderRadius: '8px',
    padding: '13px 54px',
    fontWeight: 400,
    fontSize: '16px',
    textTransform: 'none',
    lineHeight: '22px',
    color: '#FFFFFF',
  };
});
