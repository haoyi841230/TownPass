import { Box, Tab, Tabs } from '@mui/material';
import { SyntheticEvent, useState } from 'react';

type variantTypes = 'fullWidth' | 'standard' | 'scrollable' | undefined;
type wrapperWidthTypes = 'fit-content' | '100%' | undefined;

interface useTabsProps {
  readonly variant: variantTypes;
  readonly wrapperWidth?: wrapperWidthTypes;
  readonly ariaLabel: string;
  readonly tabValues: tabValues[];
  readonly centered?: boolean;
}

interface tabValues {
  label: string;
  value: string;
}

export const useTabSelection = (props: useTabsProps) => {
  const { variant, ariaLabel, tabValues, centered, wrapperWidth = 'fit-content' } = props;
  const [currentTab, setCurrentTab] = useState<string>(tabValues[0].value);

  const handleChange = (_event: SyntheticEvent, newTabValue: string) => setCurrentTab(newTabValue);

  const TabSelection = () => (
    <Box width="fit-content" sx={{ borderBottom: 1, borderColor: 'divider', width: wrapperWidth }}>
      <Tabs value={currentTab} onChange={handleChange} variant={variant} aria-label={ariaLabel} centered={centered}>
        {tabValues.map((tab) => (
          <Tab
            key={tab.value}
            label={tab.label}
            value={tab.value}
            disableRipple
            sx={{ textTransform: 'none', fontWeight: currentTab === tab.value ? 700 : 'unset' }}
          />
        ))}
      </Tabs>
    </Box>
  );

  return { currentTab, TabSelection };
};
