import { TextField, styled } from '@mui/material';

export const StyledTextField = styled(TextField)(({ theme }) => ({
  '.MuiInputBase-input': {
    color: theme.palette.grey[400],
  },
  '.MuiOutlinedInput-notchedOutline': {
    borderRadius: '10px',
    border: `1px solid ${theme.palette.grey[200]}`,
    color: '#F1F3F4',
  },
}));
