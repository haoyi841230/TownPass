import { Avatar, Box, Stack, useTheme, Typography } from '@mui/material';
import { Swiper, SwiperSlide } from 'swiper/react';
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder';
import { useNavigate } from 'react-router-dom';
const MOCKED_DATA = [{}];

export const RankCarousel = () => {
  const theme = useTheme();
  const navigate = useNavigate();
  return (
    <Swiper
      style={{ width: '100%', height: '100%' }}
      loop
      autoHeight
      slidesPerView="auto"
      spaceBetween={10}
      pagination={{
        clickable: true,
      }}
      className="mySwiper"
    >
      <SwiperSlide style={{ width: '250px', height: '200px', overflow: 'visible' }}>
        <Stack
          height="100%"
          width="100%"
          sx={{
            borderRadius: '8px',
            backgroundColor: 'common.white',
          }}
          onTouchStart={() => navigate('/like/1')}
        >
          <Typography variant="h2" color="text.primary" sx={{ mt: 1, ml: 1 }}>
            # 1
          </Typography>
          <Stack alignItems="end" justifyContent="flex-end" height="100%">
            <Avatar sx={{ backgroundColor: 'primary.main', mr: 0.5, mb: 0.5 }}>
              <FavoriteBorderIcon sx={{ color: 'common.white' }} />
            </Avatar>
          </Stack>
        </Stack>
      </SwiperSlide>
    </Swiper>
  );
};

export default RankCarousel;
