import { Avatar, ButtonBase, Grid2, Stack, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import TranslateIcon from '@mui/icons-material/Translate';
import AssignmentIndIcon from '@mui/icons-material/AssignmentInd';
import TipsAndUpdatesIcon from '@mui/icons-material/TipsAndUpdates';
import TempleHinduIcon from '@mui/icons-material/TempleHindu';
import WorkIcon from '@mui/icons-material/Work';
import SupervisedUserCircleIcon from '@mui/icons-material/SupervisedUserCircle';

const categories = [
  { class: '語言類', icon: <TranslateIcon sx={{ color: 'common.white' }} />, path: '/language' },
  { class: '人文類', icon: <TempleHinduIcon sx={{ color: 'common.white' }} />, path: '/humanities' },
  { class: '職訓類', icon: <AssignmentIndIcon sx={{ color: 'common.white' }} />, path: '/vocational-training' },
  { class: '管理類', icon: <SupervisedUserCircleIcon sx={{ color: 'common.white' }} />, path: '/management' },
  { class: '公務類', icon: <WorkIcon sx={{ color: 'common.white' }} />, path: '/public-affairs' },
  { class: '資訊類', icon: <TipsAndUpdatesIcon sx={{ color: 'common.white' }} />, path: '/information' },
];

export const Category = () => {
  const navigate = useNavigate();
  const handleNavigate = (path: string) => navigate(path);
  return (
    <Grid2 container justifyContent="center" alignItems="center" width="100%" columnSpacing={2}>
      {categories.map((category) => (
        <Grid2 size={4} key={category.class} display="flex" justifyContent="center" alignItems="center">
          <ButtonBase onClick={() => handleNavigate(category.path)} sx={{ p: 3, borderRadius: '8px' }}>
            <Stack spacing={0.5} direction="column">
              <Avatar sx={{ backgroundColor: 'primary.main' }}>{category.icon}</Avatar>
              <Typography variant="h3" color="text.primary">
                {category.class}
              </Typography>
            </Stack>
          </ButtonBase>
        </Grid2>
      ))}

      <Grid2 size={12}></Grid2>
    </Grid2>
  );
};
