const CategoryPage = () => {
  return <div>CategoryPage</div>;
};

export default CategoryPage;
