import { Typography, Stack, Grid2, Paper, Avatar } from '@mui/material';
import { RankCarousel } from '../components/homePage/RankCarousel';
import { useNavigate } from 'react-router-dom';
import CastForEducationIcon from '@mui/icons-material/CastForEducation';
import SchoolIcon from '@mui/icons-material/School';
import AssuredWorkloadIcon from '@mui/icons-material/AssuredWorkload';
import { Category } from '../components/homePage/Category';

export const HomePage = () => {
  const navigate = useNavigate();

  return (
    <Stack alignItems="center" justifyContent="center">
      <Typography variant="h3" color="text.primary" mb={6} fontWeight={700}>
        台北市課程資源
      </Typography>

      <Stack alignItems="center" justifyContent="center" spacing={3}>
        <Grid2 container width="100%" spacing={1} height="30vh" mb={3}>
          <Grid2 size={7} height="100%">
            <Paper
              onClick={() => navigate('/online-course')}
              elevation={0}
              sx={{
                borderRadius: '8px',
                p: 2,
                display: 'flex',
                flexDirection: 'column',
                height: '100%',
                backgroundColor: 'primary.main',
                gap: 2,
              }}
            >
              <Avatar sx={{ bgcolor: 'common.white', width: '50px', height: '50px' }}>
                <CastForEducationIcon sx={{ color: 'primary.main', width: '30px', height: '30px' }} />
              </Avatar>
              <Stack>
                <Typography variant="h3" color="common.white" fontWeight={600}>
                  線上課程
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  Online course
                </Typography>
              </Stack>
            </Paper>
          </Grid2>
          <Grid2 size={5} display="flex" flexDirection="column" gap={0.5} height="100%">
            <Paper
              onClick={() => navigate('/in-person-course')}
              elevation={0}
              sx={{
                borderRadius: '8px',
                p: 2,
                display: 'flex',
                flexDirection: 'row',
                height: ' 100%',
                gap: 1,
                justifyContent: 'space-between',
              }}
            >
              <Stack>
                <Typography variant="h3" color="primary" fontWeight={600}>
                  實體課程
                </Typography>
                <Typography variant="body1" color="text.secondary" lineHeight={1}>
                  In person course
                </Typography>
              </Stack>
              <SchoolIcon sx={{ color: 'primary.main', width: '30px', height: '30px' }} />
            </Paper>
            <Paper
              onClick={() => navigate('/tvdi')}
              elevation={0}
              sx={{
                borderRadius: '8px',
                p: 2,
                display: 'flex',
                flexDirection: 'row',
                height: ' 100%',
                gap: 1,
                justifyContent: 'space-between',
              }}
            >
              <Stack>
                <Typography variant="h3" color="primary" fontWeight={600}>
                  職訓局
                </Typography>
                <Typography variant="body1" color="text.secondary">
                  T.V.D.I
                </Typography>
              </Stack>
              <AssuredWorkloadIcon sx={{ color: 'primary.main', width: '30px', height: '30px' }} />
            </Paper>
          </Grid2>
        </Grid2>
        <Category />
        <RankCarousel />
      </Stack>
    </Stack>
  );
};
