const OnlineCoursePage = () => {
  return <div>OnlineCoursePage</div>;
};

export default OnlineCoursePage;
