const CourseDetailPage = () => {
  return <div>CourseDetailPage</div>;
};

export default CourseDetailPage;
