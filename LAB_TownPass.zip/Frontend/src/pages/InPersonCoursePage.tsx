import { ChangeEvent, useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Typography,
  Stack,
  Grid2,
  IconButton,
  Pagination,
  Select,
  MenuItem,
  SelectChangeEvent,
  InputLabel,
  FormControl,
  useTheme,
  CircularProgress,
} from '@mui/material';
import { Payload, Response } from '../api/model';
import { getAllClass } from '../api';
import { DataMap } from '../DataMap';
import MapIcon from '@mui/icons-material/Map';
import { StyledTextField } from '../components/UI/StyledTextField';
import { StyledButton } from '../components/UI/StyledButton';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';

interface queryForm extends Payload {
  上課日期: dayjs.Dayjs | null;
}

const fields = [
  { label: '年度', name: '年度' },
  { label: '課程名稱', name: '課程名稱' },
];

const TAIPEI_DISTRICTS = [
  '中正區',
  '大同區',
  '中山區',
  '松山區',
  '大安區',
  '萬華區',
  '信義區',
  '士林區',
  '北投區',
  '內湖區',
  '南港區',
  '文山區',
];

const initialRequestBody = {
  年度: 0,
  行政區: '',
  課程名稱: '',
  上課日期: null,
};

export const InPersonCoursePage = () => {
  const [fetchData, setFetchData] = useState<Response[]>([]);
  const [requestBody, setRequestBody] = useState<queryForm>(initialRequestBody);
  const [selectedClass, setSelectedClass] = useState<Response | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);

  const bottomRef = useRef<HTMLElement | null>(null);
  const theme = useTheme();

  const { data, refetch, isSuccess, isError, isLoading } = useQuery<Response[]>({
    queryKey: ['class', requestBody],
    queryFn: () => getAllClass({ ...requestBody, 上課日期: requestBody.上課日期?.toISOString() } as Payload),
    enabled: false,
  });

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setRequestBody((prev) => ({ ...prev, [name]: value }));
  };

  const handleChange = (event: SelectChangeEvent) => {
    setRequestBody((prev) => ({ ...prev, 行政區: event.target.value as string }));
  };

  const handleDateChange = (newDate: dayjs.Dayjs | null) => {
    setRequestBody((prev) => ({ ...prev, 上課日期: newDate }));
  };

  const handleSubmit = async () => {
    refetch();
  };

  const handleClear = () => setRequestBody(initialRequestBody);

  const scrollToBottom = (selectedClass: Response) => {
    setSelectedClass(selectedClass);

    const isInView = bottomRef.current ? bottomRef.current.getBoundingClientRect().bottom <= window.innerHeight : false;

    if (!isInView) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Calculate data for the current page
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentData = fetchData.slice(indexOfFirstItem, indexOfLastItem);

  // Handle page change
  const handlePageChange = (_event: ChangeEvent<unknown>, value: number) => {
    setCurrentPage(value);
  };

  useEffect(() => {
    if (isSuccess && data) {
      setFetchData(data);
    }
  }, [isSuccess, data]);

  useEffect(() => {
    if (isError) {
      setFetchData([]);
    }
  }, [isError]);

  return (
    <Stack spacing={6} alignItems="center" justifyContent="center" width="100%">
      <Typography variant="h2" color="primary" fontWeight={700}>
        課程查詢
      </Typography>

      <Stack>
        <Grid2 container rowSpacing={2} columnSpacing={1} justifyContent="center" width="100%">
          {fields.map((field) => (
            <Grid2 size={6} key={field.name}>
              <FormControl
                sx={{
                  width: '100%',
                  '& .MuiFormControl-root': {
                    m: 0,
                  },
                }}
              >
                <StyledTextField
                  label={field.label}
                  name={field.name}
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  onChange={handleInputChange}
                  value={(requestBody as any)[field.name] || ''}
                />
              </FormControl>
            </Grid2>
          ))}
        </Grid2>

        <Stack spacing={1} width="100%">
          <FormControl sx={{ width: '100%' }}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DemoContainer components={['DatePicker']}>
                <DatePicker
                  onChange={handleDateChange}
                  label="上課日期"
                  sx={{
                    '.MuiOutlinedInput-notchedOutline': {
                      borderColor: theme.palette.customGrey[200],
                      borderRadius: '8px',
                    },
                  }}
                  value={requestBody.上課日期}
                />
              </DemoContainer>
            </LocalizationProvider>
          </FormControl>

          <FormControl sx={{ width: '100%' }}>
            <InputLabel id="district-select-label">行政區</InputLabel>
            <Select
              labelId="district-select-label"
              id="district-select"
              value={requestBody.行政區}
              label="District"
              onChange={handleChange}
              sx={{
                '.MuiOutlinedInput-notchedOutline': {
                  borderColor: theme.palette.customGrey[200],
                  borderRadius: '8px',
                },
                '&.MuiInputBase-root': {
                  pr: '12px',
                  cursor: 'pointer',
                },
              }}
            >
              {TAIPEI_DISTRICTS.map((district: string) => (
                <MenuItem key={district} value={district}>
                  {district}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Stack>
      </Stack>

      <Stack spacing={2} direction="row">
        <StyledButton variant="outlined" color="primary" onClick={handleClear} sx={{ color: 'primary.main' }}>
          清除輸入資料
        </StyledButton>
        <StyledButton variant="contained" color="primary" onClick={handleSubmit}>
          送出
        </StyledButton>
      </Stack>
      <Stack spacing={2} width="100%">
        {currentData?.map((item: Response, index: number) => (
          <Stack
            key={item.課程名稱 + index}
            width="100%"
            spacing={3}
            direction="row"
            justifyContent="center"
            alignItems="center"
          >
            <Stack direction="column" width="100%" justifyContent="flex-start" alignItems="start">
              <Typography variant="h3" fontWeight={900}>
                {`${index + indexOfFirstItem + 1}.`}
              </Typography>

              <Typography variant="h3" fontWeight={700}>
                年度：{item.年度}
              </Typography>

              <Typography variant="h3" fontWeight={700}>
                {item.課程名稱}
              </Typography>
              <Stack direction="row" spacing={1}>
                <Typography variant="body1">{item.上課時間_起}</Typography>
                <Typography variant="body1">~</Typography>
                <Typography variant="body1">{item.上課時間_迄}</Typography>
              </Stack>
              <Typography variant="body1">上課人數： {item.人數}</Typography>
              <Typography variant="body1">{item.上課地點}</Typography>
            </Stack>
            <IconButton onClick={() => scrollToBottom(item)}>
              <MapIcon color="primary" />
            </IconButton>
          </Stack>
        ))}
      </Stack>
      {fetchData.length !== 0 && (
        <Pagination
          count={Math.ceil(fetchData.length / itemsPerPage)}
          page={currentPage}
          onChange={handlePageChange}
          color="primary"
        />
      )}
      {isLoading && <CircularProgress sx={{ my: 5 }} />}
      <DataMap bottomRef={bottomRef} selectedClass={selectedClass} />
    </Stack>
  );
};

export default InPersonCoursePage;
