import { Routes, Route } from 'react-router-dom';
import { DashboardLayout } from './components/layout/DashboardLayout';
import { HomePage } from './pages/HomePage';
import OnlineCoursePage from './pages/OnlineCoursePage';
import InPersonCoursePage from './pages/InPersonCoursePage';
import TvdiPage from './pages/TvdiPage';
import CourseDetailPage from './pages/CourseDetailPage';
import CategoryPage from './pages/CategoryPage';

function App() {
  return (
    <Routes>
      <Route path="/" element={<DashboardLayout />}>
        <Route index element={<HomePage />} />
        <Route path="/like/:id" element={<CourseDetailPage />} />
        <Route path="/category/:id" element={<CategoryPage />} />
        <Route path="/online-course" element={<OnlineCoursePage />} />
        <Route path="/in-person-course" element={<InPersonCoursePage />} />
        <Route path="/tvdi" element={<TvdiPage />} />
      </Route>
    </Routes>
  );
}

export default App;
