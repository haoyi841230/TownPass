import dayjs from 'dayjs';

export interface Response {
  年度: number;
  序號: number;
  行政區: string;
  上課地點: string;
  課程名稱: string;
  上課日期: string;
  上課時間_起: string;
  上課時間_迄: string;
  人數: number;
  經度: string;
  緯度: string;
}

export interface Payload {
  年度: number;
  行政區: string;
  課程名稱: string;
  上課日期: string | dayjs.Dayjs | null;
}
