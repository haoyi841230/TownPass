import axios from 'axios';
import { Payload } from './model';

export const getAllClass = async (requestBody: Payload) =>
  await axios.post('https://lab506.myds.me:3000/query', requestBody).then((res) => res.data);

export const getLatitudeAndLongitude = async ({ address, accessToken }: { address: string; accessToken: string }) => {
  const path = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json`;

  return await axios
    .get(path, {
      params: { access_token: accessToken },
    })
    .then((response) => {
      const coordinates = response.data.features[0].geometry.coordinates;
      const [longitude, latitude] = coordinates;
      return { latitude, longitude };
    })
    .catch((error) => console.log(error));
};
