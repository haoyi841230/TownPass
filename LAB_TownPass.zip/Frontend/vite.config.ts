import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import fs from 'fs';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 8012,
    https: {
      key: fs.readFileSync(path.resolve(__dirname, 'CA/RSA-privkey.pem')),
      cert: fs.readFileSync(path.resolve(__dirname, 'CA/RSA-cert.pem')),
      ca: fs.readFileSync(path.resolve(__dirname, 'CA/RSA-chain.pem')), // 添加证书链文件
    },
  },
  build: {
    outDir: 'build',
  },
});
